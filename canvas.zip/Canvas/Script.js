var canvas = document.querySelector('canvas');

canvas.height = window.innerHeight;
canvas.width = window.innerWidth;

//box
var ctx = canvas.getContext('2d');
//ctx.fillStyle = '#134577';
//ctx.fillRect(50,50,100,100);

//line
//ctx.beginPath();
//ctx.moveTo(310,100);
//ctx.lineTo(400,50);
//ctx.stroke();
//
//circle
var mouse = {
	x: undefined,
	y: undefined
}

var maxRadius = 40;

var colorArray = [
	'rgb(0,88,143)',
	'rgb(122,12,255)',
	'rgb(255,0,0)',
	'rgb(180,110,12)',
	'rgb(245,242,0)'
];

window.addEventListener('mousemove',function(event){
	mouse.x = event.x;
	mouse.y = event.y;
	console.log(mouse);
})

window.addEventListener('resize',function(){
	canvas.height = window.innerHeight;
	canvas.width = window.innerWidth;

	init();
})


function Circle(x,y,dx,dy,radius){
	this.x = x;
	this.y = y;
	this.dx = dx;
	this.dy = dy;
	this.radius = radius;
	this.minRadius = radius;
	this.color = colorArray[Math.floor(Math.random() * colorArray.length)];

	this.draw = function(){
		ctx.beginPath();
		ctx.arc(this.x,this.y,this.radius,0,Math.PI*2,false);
		ctx.fillStyle = this.color;
		ctx.fill();	
	}
	this.animation = function(){
		if(this.x + this.radius > innerWidth || this.x - this.radius < 0){
			this.dx = -this.dx;
		}
		if(this.y + this.radius > innerHeight || this.y - this.radius < 0){
			this.dy = -this.dy;
		}
		this.y += this.dy;
		this.x += this.dx;

		//interação

		if(mouse.x - this.x < 50 && mouse.x - this.x > -50 && mouse.y - this.y < 50 && mouse.y - this.y > -50) {
			if(this.radius < maxRadius){
				this.radius +=1;
			}
		}else if(this.radius > this.minRadius){
			this.radius -=1;
		}

		this.draw();
	}
}

		var circle = new Circle(Math.random() * innerWidth,Math.random() * innerHeight,3,3,30);
		//circle.draw();
		//circle.animation();

var circleArray = [];

function init(){

	circleArray = [];
	for (var i = 0; i < 800; i++) {
		var radius = Math.random() * 5 + 1;
		var x = Math.random() * (innerWidth - radius * 2)+ radius;
		var dx = (Math.random() -0.5);
		var y = Math.random() * (innerHeight - radius * 2)+ radius;
		var dy = (Math.random() -0.5);

		circleArray.push(new Circle(x,y,dx,dy,radius));
	}
}
console.log(circleArray);

function animate(){
	requestAnimationFrame(animate);
		ctx.clearRect(0,0,innerWidth,innerHeight);
	
	for(var i = 0 ;i < circleArray.length; i++){
		circleArray[i].animation();
	}
}
animate();
init();
